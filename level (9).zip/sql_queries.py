import sqlite3
conn = sqlite3.connect('Artistc.db')
cursor = conn.cursor()



# Вопрос 1. Информация о скольких художниках представлена в базе данных? 
cursor.execute('SELECT * FROM artists')
data = cursor.fetchall()
print('сколько художников', len(data))

# Вопрос 2. Сколько женщин (Female) в базе?
cursor.execute('SELECT * FROM artists WHERE Gender == "Female"')
data = cursor.fetchall()
print('Сколько женщин', len(data))


# Вопрос 3. Сколько человек в базе данных родились до 1900 года?
cursor.execute('SELECT * FROM artists WHERE "Birth Year"<1900')
data = cursor.fetchall()
print('Сколько художников, чьи данные имеются в базе, родились до 1900 года', len(data))


