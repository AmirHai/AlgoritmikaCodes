# напиши здесь свое приложение
from instructions import *
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput

class FirstScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        text1 = Label(text = txt_instruction)
        name = Label(text = 'Введите имя')
        age = Label(text = 'Введите возраст')

        nameinput = TextInput(multiline = False)
        ageinput = TextInput(text = '7', multiline = False)
        btn = Button(text = 'Начать', size_hint = (0.3, None), pos_hint = {'center_x':0.5})
        btn.on_press = self.next
        mainlayout = BoxLayout(orientation = 'vertical')
        l1 = BoxLayout(size_hint = (0.8, None), height = '30sp')
        l2 = BoxLayout(size_hint = (0.8, None), height = '30sp')
        l1.add_widget(name)
        l1.add_widget(nameinput)
        l2.add_widget(age)
        l2.add_widget(ageinput)
        mainlayout.add_widget(text1)
        mainlayout.add_widget(l1)
        mainlayout.add_widget(l2)
        mainlayout.add_widget(btn)
        self.add_widget(mainlayout)
    def next(self):
        self.manager.current = 'second'





class SecondScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        text2 = Label(text = txt_test1)
        test1 = Label(text = 'Введите результат:')
        testinput1 = TextInput(multiline = False)
        btn1 = Button(text = 'Продолжить', size_hint = (0.3, None), pos_hint = {'center_x':0.5})
        btn1.on_press = self.next
        mainlayout1 = BoxLayout(orientation = 'vertical')
        l3 = BoxLayout(size_hint = (0.8, None), height = '30sp')
        l3.add_widget(test1)
        l3.add_widget(testinput1)
        mainlayout1.add_widget(text2)
        mainlayout1.add_widget(l3)
        mainlayout1.add_widget(btn1)
        self.add_widget(mainlayout1)
    def next(self):
        self.manager.current = 'third'
        
        

class ThirdScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        text3 = Label(text = txt_sits)
        btn2 = Button(text = 'Продолжить', size_hint = (0.3, None), pos_hint = {'center_x':0.5})
        btn2.on_press = self.next
        mainlayout2 = BoxLayout(orientation = 'vertical')
        mainlayout2.add_widget(text3)
        mainlayout2.add_widget(btn2)
        self.add_widget(mainlayout2)
    def next(self):
        self.manager.current = 'forth'


class ForthScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        text4 = Label(text = txt_test3)
        text5 = Label(text = 'Результат:')
        text6 = Label(text = 'Результат после отдыха:')
        rezinput = TextInput(multiline = False)
        rezinput1 = TextInput(multiline = False)
        btn3 = Button(text = 'Завершить', size_hint = (0.3, None), pos_hint = {'center_x':0.5})
        btn3.on_press = self.next
        mainlayout3 = BoxLayout(orientation = 'vertical')
        l4 = BoxLayout(size_hint = (0.8, None), height = '30sp')
        l5 = BoxLayout(size_hint = (0.8, None), height = '30sp')
        mainlayout3.add_widget(text4)
        l4.add_widget(text5)
        l4.add_widget(rezinput)
        l5.add_widget(text6)
        l5.add_widget(rezinput1)
        mainlayout3.add_widget(l4)
        mainlayout3.add_widget(l5)
        mainlayout3.add_widget(btn3)
        self.add_widget(mainlayout3)
    def next(self):
        self.manager.current = 'fifth'
        

class FifthScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

class MainApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(FirstScreen(name = 'first'))
        sm.add_widget(SecondScreen(name = 'second'))
        sm.add_widget(ThirdScreen(name = 'third'))
        sm.add_widget(ForthScreen(name = 'forth'))
        sm.add_widget(FifthScreen(name = 'fifth'))

        return sm
mainapp = MainApp()
mainapp.run()